package com.example.jsfw_l_a102_blogs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JsfwLA102BlogsApplicationTests {

	@Test
	void contextLoads() {
	}

}
