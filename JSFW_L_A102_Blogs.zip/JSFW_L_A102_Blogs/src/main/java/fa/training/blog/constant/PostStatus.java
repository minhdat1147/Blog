package fa.training.blog.constant;

public class PostStatus {
    public static final int DRAFT = 1;
    public static final int PUBLISHED =2;
    public static final int OUTDATED =3;
}
