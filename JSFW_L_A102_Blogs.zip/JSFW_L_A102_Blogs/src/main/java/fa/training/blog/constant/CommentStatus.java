package fa.training.blog.constant;

public class CommentStatus {
    public static final int APPROVE =2;
    public static final int UN_APPROVE =1;
}
